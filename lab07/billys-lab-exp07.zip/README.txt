⚗️ Billy's Lab: Experiment 07
Unstable stickers. Handle with style.

On iPhone: press and hold a sticker, then Save to Photos or Copy.
