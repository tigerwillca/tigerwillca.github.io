Billy Stickers — 2026-11-15 v2.5
==================================

A 12-sticker iMessage set for Billy. Original art. 408x408 looping GIFs,
24 frames, under 500 KB, infinite loop, sRGB. One cube only (01).
No tiny text. Kid- and school-friendly.

v2.5 changes
------------
  • 07-star-wolf was redrawn so it reads as a howling wolf at a glance.
    The inner chest V (the mid-chest dip star and the two lines down to
    it) is gone. A short jaw-to-occiput line sits under the head instead.
    The snout wedge is longer (about 1.6x v2.4) and still points up-left.
    Two ears sit tucked at the crown, spread apart and swept back toward
    the tail, so the snout can grow forward. The snout-to-ears span stays
    at or under about one quarter of the sticker width. Forelegs stay
    short and bent; the hooked tail is unchanged from v2.4.
    The twinkle is a smooth pulse (about 0.10 max frame-to-frame
    mean-luminance step, between 0.08 and 0.12; one cycle per loop,
    under 3 big swings per second).
    Frames 0 and 23 show the complete outline (no blank wrap).
  • Every other GIF is byte-identical to v2.4.
  • Numbering still skips 08 on purpose (08-soft-magic was retired in v2).

The stickers
------------
  01-cube-assemble.gif    485.1 KB   Metatron's Cube assembles from a faint seed circle, then 13 Fruit of Life circles fade in
  02-coming-soon.gif      149.7 KB   Starfield warp and a four-point gold spark
  03-wolf-eyes.gif        257.7 KB   Howling wolf under a crescent moon
  04-the-pack.gif         304.1 KB   Three-wolf pack on a ridge under a plain moon
  05-third-eye.gif        341.9 KB   Sitting wolf with a third eye
  06-neural-streams.gif   297.5 KB   Neural hub with a round soma, forked dendrites, and traveling pulses
  07-star-wolf.gif        243.0 KB   Howling constellation wolf: 45-degree up-left head wedge, long snout, two crown ears swept back, no inner V, bent sitting forelegs, hooked tail, raised smooth twinkle
  09-pegasus.gif          476.2 KB   Pegasus with a gentle wing sheen
  10-tiger.gif            417.5 KB   Navy-and-gold tiger cub
  11-reynard.gif          349.9 KB   Reynard the red fox
  12-raccoon.gif          397.9 KB   Raccoon with a ringed tail
  13-owl.gif              389.3 KB   Wide-eyed navy-and-gold owl

How to use on iPhone
--------------------
1. AirDrop this folder or the zip to the iPhone, or save the GIFs to Photos.
2. Open a Messages (iMessage) thread.
3. Tap Photos, or share a GIF from Photos into Messages.
4. Press and hold the sticker, then send it. You can also drag it onto a bubble.

Notes
-----
  • 618 px large set is not included in this zip (not every file was under 500 KB).
  • Earlier versions were kept in v1/, gif/408/ (v2), gif/408-v2.1/,
    gif/408-v2.2/, gif/408-v2.3/, and gif/408-v2.4/; nothing was deleted.
  • Animals in 03-05 and 09-13 are illustrated sticker art.
  • 07 is a star-dot constellation (no solid body fill).
  • A real iPhone check by William is still needed before the pack is shared.

STATUS: v2.5 built; pending core-team sign-off. Not yet shown to William.
