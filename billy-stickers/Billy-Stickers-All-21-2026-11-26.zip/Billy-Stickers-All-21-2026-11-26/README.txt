Billy Stickers — all 21  (2026-11-26)
====================================

Drop 1 — Midnight Gold (8 looping GIFs, 408×408)
  bro, say-less, w, l, cooked, npc, seven, third-eye

Drop 1 — Swirl Ink (6 looping GIFs + transparent PNGs, 512×512)
  01-swirl, 02-wink, 03-galaxy, 04-heart, 05-starburst, 06-orbit

Drop 2 — Swirl Ink Moods + peel-and-stick overlays (7 GIFs + PNGs, 512×512)
  01-locked-in, 02-wait-what, 03-no-way, 04-chill,
  05-glowing-crown, 06-swirl-shades, 07-bet

All GIFs loop and are under 500 KB. See HOW-TO.txt for iPhone steps.
